package com.jinko.vegas;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

/** JINKO companion: local notes only, no modification of the game. */
public class MainActivity extends Activity {
    private static final String GAME_PACKAGE = "com.gameloft.android.ANMP.GloftGGHM";
    private WebView web;

    public class CompanionBridge {
        @JavascriptInterface
        public String getInstalledVersion() {
            try {
                PackageInfo info = getPackageManager().getPackageInfo(GAME_PACKAGE, 0);
                return info.versionName != null ? info.versionName : "Installed";
            } catch (PackageManager.NameNotFoundException e) {
                return "Game not found (check Play Store installation)";
            } catch (Exception e) {
                return "Version check unavailable";
            }
        }

        @JavascriptInterface
        public String openGame() {
            try {
                Intent intent = getPackageManager().getLaunchIntentForPackage(GAME_PACKAGE);
                if (intent == null) return "Game launcher not found";
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                runOnUiThread(() -> startActivity(intent));
                return "Opening Gangstar Vegas";
            } catch (Exception e) {
                return "Could not open the game";
            }
        }

        @JavascriptInterface
        public void shareBackup(String content) {
            if (content == null || content.length() > 1000000) return;
            runOnUiThread(() -> {
                Intent send = new Intent(Intent.ACTION_SEND);
                send.setType("text/plain");
                send.putExtra(Intent.EXTRA_SUBJECT, "JINKO Vegas Companion backup");
                send.putExtra(Intent.EXTRA_TEXT, content);
                startActivity(Intent.createChooser(send, "Share companion backup"));
            });
        }
    }

    @Override
    public void onCreate(Bundle state) {
        super.onCreate(state);
        web = new WebView(this);
        web.setWebViewClient(new WebViewClient());
        WebSettings settings = web.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowFileAccessFromFileURLs(false);
        settings.setAllowUniversalAccessFromFileURLs(false);
        settings.setJavaScriptCanOpenWindowsAutomatically(false);
        web.addJavascriptInterface(new CompanionBridge(), "JinkoAndroid");
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
    }

    @Override
    public void onBackPressed() {
        if (web != null && web.canGoBack()) web.goBack();
        else super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        if (web != null) web.destroy();
        super.onDestroy();
    }
}
