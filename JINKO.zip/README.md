# JINKO VEGAS PREMIUM v1.2

Unofficial offline Android companion for Gangstar Vegas.

- Matches the accepted dark/purple JINKO UI.
- Stores money and diamond balances **entered by the player** (not game modifications).
- Real balance log and history chart derived from saved data.
- Customizable car and weapon checklists with progress indicators.
- Offline local storage, export/share JSON backup and restore.
- Opens Gangstar Vegas and checks its installed version on Android where available.
- `© JINKO | All Rights Reserved` appears in the UI.

**Not a cheat**: does not modify memory, currency, diamonds, server accounts, cars, weapons or unlocks in the game.

Build from the ZIP archive using `.github/workflows/build-apk.yml` on GitHub Actions, or open `app/src/main/assets/index.html` in a browser.

## Notes

You need a complete Gradle Android build environment to compile an APK. The chat environment may not have the Android SDK. The GitHub workflow targets the Android SDK hosted on the GitHub runner.
