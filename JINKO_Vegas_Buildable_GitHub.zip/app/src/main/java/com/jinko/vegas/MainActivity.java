package com.jinko.vegas;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class MainActivity extends Activity {
  private static final String GAME_PACKAGE = "com.gameloft.android.ANMP.GloftGGHM";
  private WebView web;

  public class GameBridge {
    @JavascriptInterface
    public String getInstalledVersion() {
      try {
        PackageInfo info = getPackageManager().getPackageInfo(GAME_PACKAGE, 0);
        return info.versionName == null ? "Installed (version unknown)" : info.versionName;
      } catch (PackageManager.NameNotFoundException e) {
        return "Not installed or inaccessible";
      } catch (Exception e) {
        return "Version check unavailable";
      }
    }

    @JavascriptInterface
    public String openGame() {
      try {
        Intent i = getPackageManager().getLaunchIntentForPackage(GAME_PACKAGE);
        if (i == null) return "Cannot locate Gangstar Vegas launcher";
        runOnUiThread(() -> startActivity(i));
        return "Opening Gangstar Vegas";
      } catch (Exception e) {
        return "Could not open game";
      }
    }
  }

  @Override public void onCreate(Bundle state) {
    super.onCreate(state);
    web = new WebView(this);
    web.setWebViewClient(new WebViewClient());
    WebSettings s = web.getSettings();
    s.setJavaScriptEnabled(true);
    s.setDomStorageEnabled(true);
    s.setAllowFileAccess(true);
    // The native bridge is exposed only to our bundled local HTML document.
    web.addJavascriptInterface(new GameBridge(), "JinkoAndroid");
    web.loadUrl("file:///android_asset/index.html");
    setContentView(web);
  }

  @Override public void onBackPressed() {
    if(web.canGoBack()) web.goBack(); else super.onBackPressed();
  }
}
